# doggy_react.py - Updated for Doggy with Ultrasonic Sensor Reaction

import RPi.GPIO as GPIO
import time
import os

TRIG = 23
ECHO = 24

GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

def get_distance():
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()
    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()

    duration = pulse_end - pulse_start
    distance = duration * 17150
    return round(distance, 2)

print("🐶 Doggy is watching for your wave...")

try:
    while True:
        dist = get_distance()
        print(f"Distance: {dist} cm")
        if dist < 25:
            os.system('espeak "Woof! Hello friend!"')
            time.sleep(3)
        time.sleep(1)
except KeyboardInterrupt:
    GPIO.cleanup()
