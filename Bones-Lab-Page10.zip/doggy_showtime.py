# doggy_showtime.py
# Combine servo wave, LED blink, and speech

from gpiozero import Servo, LED
from time import sleep
import os

servo = Servo(18)
led = LED(17)

print("🎉 Doggy is performing!")

while True:
    led.on()
    os.system('espeak "Watch my moves!"')
    servo.min()
    sleep(1)
    servo.max()
    sleep(1)
    led.off()
    sleep(1)
