# setup_libraries.py
# Test Python libraries after installation

try:
    import ibm_watson
    import gpiozero
    import pygame
    import sounddevice
    import scipy
    print("✅ All required libraries are installed correctly!")
except Exception as e:
    print("⚠️ Some libraries are missing or failed to import:", e)
