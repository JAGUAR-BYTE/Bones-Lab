# tjbot_listen.py
# Make TJBot listen using IBM Watson STT

import sounddevice as sd
from scipy.io.wavfile import write
from ibm_watson import SpeechToTextV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# IBM Watson Credentials
apikey = '<API_KEY>'
url = '<STT_SERVICE_URL>'

authenticator = IAMAuthenticator(apikey)
stt = SpeechToTextV1(authenticator=authenticator)
stt.set_service_url(url)

# Record audio
print("🎤 Speak something...")
fs = 44100
duration = 5  # seconds
recording = sd.rec(int(duration * fs), samplerate=fs, channels=2)
sd.wait()
write("input.wav", fs, recording)

# Convert to text
with open("input.wav", 'rb') as audio_file:
    result = stt.recognize(audio=audio_file, content_type='audio/wav').get_result()
    text = result['results'][0]['alternatives'][0]['transcript']
    print("You said:", text)
