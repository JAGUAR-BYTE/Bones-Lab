# doggy_setup.py
# Test basic Python setup

print("✅ Python is ready!")
print("🐶 You're ready to talk to Doggy!")
