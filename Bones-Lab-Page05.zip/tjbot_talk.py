# tjbot_talk.py
# Make TJBot talk using IBM Watson TTS

from ibm_watson import TextToSpeechV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import pygame
import time

# Setup
apikey = '<API_KEY>'
url = '<TTS_SERVICE_URL>'

authenticator = IAMAuthenticator(apikey)
tts = TextToSpeechV1(authenticator=authenticator)
tts.set_service_url(url)

def speak(text):
    with open("speak.mp3", "wb") as audio_file:
        response = tts.synthesize(
            text,
            voice='en-US_AllisonV3Voice',
            accept='audio/mp3'
        ).get_result()
        audio_file.write(response.content)

    pygame.mixer.init()
    pygame.mixer.music.load("speak.mp3")
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        time.sleep(0.1)

speak("Hello, I am TJBot! Let's start learning together!")
