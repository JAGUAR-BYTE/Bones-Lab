print("Hello from TJBot & Doggy!")
# This is your first test program
