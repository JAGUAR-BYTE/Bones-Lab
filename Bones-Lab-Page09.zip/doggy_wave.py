# doggy_wave.py
# Wave using servo motor on GPIO18

from gpiozero import Servo
from time import sleep

servo = Servo(18)
print("🐾 Doggy is waving hello!")

while True:
    servo.min()
    sleep(1)
    servo.max()
    sleep(1)
